-- Use the schema
DROP DATABASE IF EXISTS survey_builder;
CREATE DATABASE survey_builder;
USE survey_builder;

-- ===============================
-- Table 1: Users
-- ===============================
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    email VARCHAR(100),
    is_anonymous BOOLEAN DEFAULT FALSE
);

-- ===============================
-- Table 2: Surveys
-- ===============================
CREATE TABLE surveys (
    survey_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    description TEXT,
    start_date DATE,
    end_date DATE
);

-- ===============================
-- Table 3: Question Types
-- ===============================
CREATE TABLE question_types (
    type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(50) -- e.g. 'single_choice', 'multiple_choice', 'text', 'rating'
);

-- ===============================
-- Table 4: Questions
-- ===============================
CREATE TABLE questions (
    question_id INT AUTO_INCREMENT PRIMARY KEY,
    survey_id INT,
    question_text TEXT,
    type_id INT,
    question_order INT,
    FOREIGN KEY (survey_id) REFERENCES surveys(survey_id),
    FOREIGN KEY (type_id) REFERENCES question_types(type_id)
);

-- ===============================
-- Table 5: Options (For MCQ/SCQ)
-- ===============================
CREATE TABLE options (
    option_id INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT,
    option_text VARCHAR(255),
    FOREIGN KEY (question_id) REFERENCES questions(question_id)
);

-- ===============================
-- Table 6: Responses
-- ===============================
CREATE TABLE responses (
    response_id INT AUTO_INCREMENT PRIMARY KEY,
    survey_id INT,
    user_id INT,
    response_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (survey_id) REFERENCES surveys(survey_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- ===============================
-- Table 7: Answers (All types)
-- ===============================
CREATE TABLE answers (
    answer_id INT AUTO_INCREMENT PRIMARY KEY,
    response_id INT,
    question_id INT,
    selected_option_id INT NULL,     -- For SCQ/MCQ
    answer_text TEXT NULL,           -- For Text/Rating
    FOREIGN KEY (response_id) REFERENCES responses(response_id),
    FOREIGN KEY (question_id) REFERENCES questions(question_id),
    FOREIGN KEY (selected_option_id) REFERENCES options(option_id)
);



-- ===============================
-- Queries for Dashboard
-- ===============================

-- 1. Count of Responses per Survey
SELECT s.title, COUNT(r.response_id) AS total_responses
FROM surveys s
JOIN responses r ON s.survey_id = r.survey_id
GROUP BY s.survey_id;

-- 2. Average Rating for Rating Questions
SELECT q.question_text, AVG(CAST(a.answer_text AS DECIMAL)) AS avg_rating
FROM questions q
JOIN answers a ON q.question_id = a.question_id
JOIN question_types qt ON q.type_id = qt.type_id
WHERE qt.type_name = 'rating'
GROUP BY q.question_id;

-- 3. Text Answers Summary
SELECT q.question_text, a.answer_text
FROM questions q
JOIN answers a ON q.question_id = a.question_id
JOIN question_types qt ON q.type_id = qt.type_id
WHERE qt.type_name = 'text';

-- 4. Single Choice Response Count
SELECT q.question_text, o.option_text, COUNT(*) AS count
FROM answers a
JOIN questions q ON a.question_id = q.question_id
JOIN options o ON a.selected_option_id = o.option_id
JOIN question_types qt ON q.type_id = qt.type_id
WHERE qt.type_name = 'single_choice'
GROUP BY q.question_id, o.option_id;

-- ===============================
-- END
-- ===============================
